const projectsData = require("../../data.js");

export const projects = projectsData;
