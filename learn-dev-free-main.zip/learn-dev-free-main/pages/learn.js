import React, { Component } from 'react'

export default class learn extends Component {
    render() {
        return (
            <div>
                This is projects showcase
            </div>
        )
    }
}
